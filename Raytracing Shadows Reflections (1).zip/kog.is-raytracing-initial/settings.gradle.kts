include("client")//## multi-project build template; a single included subproject
rootProject.name = "kog"